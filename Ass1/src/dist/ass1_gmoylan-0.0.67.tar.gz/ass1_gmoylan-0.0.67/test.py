byt = b"\xAA\xBB\xCC"
print(f'Producer{int.from_bytes(byt, byteorder="little")}')